/*
*	DKU Operating System Lab
*	    Lab1 (Scheduler Algorithm Simulator)
*	    Student id : 32200566
*	    Student name : 김민정
*
*   lab1_sched.c :
*       - Lab1 source file.
*       - Must contains scueduler algorithm test code.
*
*/

#include <aio.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <assert.h>
#include <pthread.h>
#include <asm/unistd.h>

#include "lab1_sched_types.h"

/*
 * you need to implement scheduler simlator test code.
 *
 */

int main(int argc, char *argv[]){
	process1();
	printf("===========================FIFO(1)===========================\n");
	FCFS();
	printf("\n");

	process1();
	printf("===========================RR(1)===========================\n");
	RR();
	printf("\n");
	
	printf("===========================SPN(1)===========================\n");
	process1();
	SPN();
	printf("\n");
	
	printf("===========================HRRN(1)===========================\n");
	process1();
	HRRN();
	printf("\n\n");


	process2();
	printf("===========================FIFO(2)===========================\n");
	FCFS();
	printf("\n");

	process2();
	printf("===========================RR(2)===========================\n");
	RR();
	printf("\n");

	process2();
	printf("===========================SPN(2)===========================\n");
	SPN();
	printf("\n");

	process2();
	printf("===========================HRRN(2)===========================\n");
	HRRN();
	printf("\n");

	printf("===========================lottery===========================\n");
	lottery();
	printf("\n");

}

